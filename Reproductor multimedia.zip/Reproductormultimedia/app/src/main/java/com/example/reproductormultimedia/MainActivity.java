package com.example.reproductormultimedia;

import android.net.Uri;
import android.os.Bundle;

import com.example.reproductormultimedia.ui.main.videosFragment;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.MediaController;
import android.widget.VideoView;

import com.example.reproductormultimedia.ui.main.SectionsPagerAdapter;
import com.example.reproductormultimedia.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    String url = "https://videocdn.bodybuilding.com/video/mp4/62000/62792m.mp4";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());
        ViewPager viewPager = binding.viewPager;
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabs = binding.tabs;
        tabs.setupWithViewPager(viewPager);
        FloatingActionButton fab = binding.fab;
        setupTabLayout(tabs);

        //try{
            //VideoView videoView = findViewById(R.id.videoview);


            // Uri object to refer the
            // resource from the videoUrl
            //Uri uri = Uri.parse(url);

            // sets the resource from the
            // videoUrl to the videoView
            //videoView.setVideoURI(uri);
            //videoView.setVideoPath("http://videocdn.bodybuilding.com/video/mp4/62000/62792.mp4");

            // creating object of
            // media controller class
           // MediaController mediaController = new MediaController(this);

            // sets the anchor view
            // anchor view for the videoView
           // mediaController.setAnchorView(videoView);

            // sets the media player to the videoView
            //mediaController.setMediaPlayer(videoView);

            // sets the media controller to the videoView
           // videoView.setMediaController(mediaController);

            // starts the video
            //videoView.start();
        //}catch (Exception e){
        //    Log.e("Error video", e.getMessage());
        //}

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }
    private void setupTabLayout(TabLayout tabs){
        tabs.getTabAt(0).setIcon(R.drawable.house);
        tabs.getTabAt(1).setIcon(R.drawable.heart);
        tabs.getTabAt(2).setIcon(R.drawable.music);
        tabs.getTabAt(3).setIcon(R.drawable.camera);
    }
}