package com.example.clasedialogos

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val boton = findViewById<Button>(R.id.buttonClick)
        val nombre = findViewById<EditText>(R.id.editTextNombre)

        boton.setOnClickListener {
            val dialogo = AlertDialog.Builder(this)
            dialogo.setMessage("El nombre es ${nombre.text}. ¿Es correcto?")
                .setCancelable(false)
                .setPositiveButton("Sí") {
                        dialog, id ->
                    val toast: Toast = Toast.makeText(this, nombre.text, Toast.LENGTH_LONG)
                    toast.show()
                }
                .setNegativeButton("No") {
                        dialog, id -> dialog.cancel()
                }

            val alerta = dialogo.create()
            alerta.setTitle("Mi primera alerta :D")
            alerta.show()
        }
    }
}