package com.example.ejemplointent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    public final static String EXTRA_NOMBRE = "Buenas";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void paginaWeb(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=Gzs60iBgd3E"));
        startActivity(intent);
    }

    public void llamar(View view){
        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:617611653"));
        startActivity(intent);
    }

    public void maps(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://goo.gl/maps/t7Wj6BJyregeL27w7"));
        startActivity(intent);
    }

    public void otraActividad(View view) {
        Intent intent = new Intent(MainActivity.this, MainActivity2.class);
        intent.putExtra(EXTRA_NOMBRE, "Probando cosas");
        startActivity(intent);
    }
}