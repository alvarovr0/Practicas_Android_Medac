package com.example.practicaevaluable;

import java.util.ArrayList;

public class Lista {
    public ArrayList<ListaEntrada> datos;

    Lista(){
        datos = new ArrayList<ListaEntrada>();
        datos.add(new ListaEntrada(R.drawable.seniordelosanillos, "El señor de los anillos La comunidad del anillo", "2001"));
        datos.add(new ListaEntrada(R.drawable.toystory, "Toy Story", "1995"));
        datos.add(new ListaEntrada(R.drawable.reyleon, "El rey león", "1994"));
        datos.add(new ListaEntrada(R.drawable.shinchan, "Shin-Chan: ¡Los adultos contraatacan!", "2001"));
        datos.add(new ListaEntrada(R.drawable.spider, "Spiderman 3", "2007"));
    }

    public ArrayList<ListaEntrada> devolverDatos(){
        return datos;
    }
}
