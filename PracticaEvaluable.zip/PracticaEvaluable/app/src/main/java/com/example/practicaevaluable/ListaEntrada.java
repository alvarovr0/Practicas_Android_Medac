package com.example.practicaevaluable;

public class ListaEntrada {
    private int idImagen;
    private String textoEncima, textoDebajo;

    public ListaEntrada(int idImagen, String textoTitulo, String textoAnio){
        this.idImagen = idImagen;
        this.textoEncima = textoTitulo;
        this.textoDebajo = textoAnio;
    }

    public String getTextoDebajo() {
        return this.textoDebajo;
    }

    public String getTextoEncima() {
        return this.textoEncima;
    }

    public int getIdImagen() {
        return this.idImagen;
    }
}
