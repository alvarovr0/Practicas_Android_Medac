package com.example.practicaevaluable;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class DatosPeli extends AppCompatActivity {
    String texto_sup_entrada;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datos_peli);
        TextView titulo = (TextView)findViewById(R.id.titulo);
        ImageView imagen = (ImageView)findViewById(R.id.caratula);
        TextView sinopsis = (TextView)findViewById(R.id.sinopsis);
        Intent intent = getIntent();
        String name = intent.getStringExtra("Titulo");
        int image = intent.getIntExtra("Imagen",0);
        String resumen = intent.getStringExtra("Sinopsis");
        titulo.setText(name);
        imagen.setImageResource(image);
        sinopsis.setText(resumen);
    }
    public void volverAtras(View view) {
        Intent intent = new Intent(DatosPeli.this, MainActivity.class);
        startActivity(intent);
    }
}