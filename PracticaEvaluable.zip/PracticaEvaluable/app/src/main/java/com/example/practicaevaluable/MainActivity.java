package com.example.practicaevaluable;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ListView lista;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Lista listado = new Lista();
        ArrayList<ListaEntrada> datos = listado.devolverDatos();
        lista = (ListView) findViewById(R.id.Listado);

        lista.setAdapter(new ListaAdaptador(this, R.layout.pelis, datos) {
            @Override
            public void onEntrada(Object entrada, View view) {
                if (entrada != null) {
                    TextView texto_sup_entrada = (TextView) view.findViewById(R.id.titulo);
                    if (texto_sup_entrada != null) {
                        texto_sup_entrada.setText(((ListaEntrada) entrada).getTextoEncima());
                    }
                    TextView texto_inf_entrada = (TextView) view.findViewById(R.id.anio);
                    if (texto_inf_entrada != null) {
                        texto_inf_entrada.setText(((ListaEntrada) entrada).getTextoDebajo());
                    }
                    ImageView imagenEntrada = (ImageView) view.findViewById(R.id.imageView_image);
                    if (imagenEntrada != null) {
                        imagenEntrada.setImageResource(((ListaEntrada) entrada).getIdImagen());
                    }
                }
            }
        });

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                ListaEntrada elegido = (ListaEntrada) adapterView.getItemAtPosition(i);
                Context context = getApplicationContext();
                if(!elegido.getTextoEncima().equals("Shin-Chan: ¡Los adultos contraatacan!")){
                    Intent intent = new Intent(MainActivity.this, DatosPeli.class);
                    switch (elegido.getTextoEncima()){
                        case "El señor de los anillos La comunidad del anillo":
                            String sinopsis = getString(R.string.sinSeni);
                            intent.putExtra("Titulo", elegido.getTextoEncima());
                            intent.putExtra("Imagen",elegido.getIdImagen());
                            intent.putExtra("Sinopsis", sinopsis);
                            break;
                        case "Toy Story":
                            String sinopsis1 = getString(R.string.sinToy);
                            intent.putExtra("Titulo", elegido.getTextoEncima());
                            intent.putExtra("Imagen",elegido.getIdImagen());
                            intent.putExtra("Sinopsis",sinopsis1);
                            break;
                        case "El rey león":
                            String sinopsis2 = getString(R.string.sinLeo);
                            intent.putExtra("Titulo", elegido.getTextoEncima());
                            intent.putExtra("Imagen",elegido.getIdImagen());
                            intent.putExtra("Sinopsis",sinopsis2);
                            break;
                        case "Spiderman 3":
                            String sinopsis3 = getString(R.string.sinSpi3);
                            intent.putExtra("Titulo", elegido.getTextoEncima());
                            intent.putExtra("Imagen",elegido.getIdImagen());
                            intent.putExtra("Sinopsis",sinopsis3);
                            break;
                    }

                    startActivity(intent);
                }else{
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.filmaffinity.com/es/film208297.html"));
                    startActivity(intent);
                }

            }
        });
    }

}