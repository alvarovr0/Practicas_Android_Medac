package com.example.coche;

public class Coches {
    public String nombre;
    public String marca;
    public int precio;

    public Coches(String nombre, String marca, int precio){
        this.nombre = nombre;
        this.marca = marca;
        this.precio = precio;
    }
}
