package com.example.coche;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private final String CADENA = "[{\"nombre_coche\":\"Gallardo\",\"marca\":\"Lamborghini\":\"precio\":\"150000€\"},\n"+
            "{\"nombre_coche\":\"RS7\",\"marca\":\"Audi\":\"precio\":\"180000€\"},\n" +
            "{\"nombre_coche\":\"Mustang\"marca\":\"Ford\":\"precio\":\"200000€\"},\n" +
            "{\"nombre_coche\":\"Supra\"marca\":\"Toyota\":\"precio\":\"300000€\"}]";
    Button botoncin;
    EditText nombre, marca, precio;
    String nombreT, marcaT;
    int precioT;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DBHelper dbHelper = new DBHelper(MainActivity.this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        if(db != null){
            Toast.makeText(MainActivity.this, "Base de datos creada", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(MainActivity.this, "Error en crear la base de datos", Toast.LENGTH_LONG).show();
        }

        try{
            JSONArray jArray = new JSONArray(CADENA);
            for(int i = 0; i <jArray.length(); i++){
                JSONObject json_data = jArray.getJSONObject(i);
                String nombre = json_data.getString("nombre_coche");
                String marca = json_data.getString("marca");
                int precio = json_data.getInt("precio");
                Coches coche = new Coches(nombre, marca, precio);
                dbHelper.insertarCoche(coche, db);
            }
        } catch (JSONException e) {
            System.out.println(e.getMessage());
        }

        nombre = findViewById(R.id.nombre);
        marca = findViewById(R.id.marca);
        precio = findViewById(R.id.precio);

        nombreT = nombre.getText().toString();
        marcaT = marca.getText().toString();
        precioT = Integer.parseInt(precio.getText().toString());

        botoncin = findViewById(R.id.boton);
        botoncin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                DBHelper dbHelper = new DBHelper(MainActivity.this);
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                Coches cochecito = new Coches(nombreT, marcaT, precioT);
                dbHelper.insertarCoche(cochecito, db);
            }
        });

    }
}