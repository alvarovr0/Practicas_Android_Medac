package com.example.coche;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    private static final int Database_Version = 1;
    private static final String Database_Name = "coches.db";
    private static final String Table = "t_coches";
    public DBHelper(@Nullable Context context) {
        super(context, Database_Name, null, Database_Version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE " + Table + "(" + "id integer primary key autoincrement," + "nombre text not null," +
                "marca text not null," + "precio number not null)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("Drop table " + Table);
        onCreate(sqLiteDatabase);
    }

    public void close(SQLiteDatabase db){
        if(db != null){
            db.close();
        }
    }

    public void insertarCoche(Coches coche, SQLiteDatabase db){
        ContentValues cv = new ContentValues();
        cv.put("nombre", coche.nombre);
        cv.put("marca", coche.marca);
        cv.put("precio", coche.precio);
        db.insert(Table, null, cv);
    }
}

