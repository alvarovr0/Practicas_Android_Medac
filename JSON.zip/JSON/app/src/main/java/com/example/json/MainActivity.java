package com.example.json;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private final String CADENA = "[{\"nombre_fruta\":\"Manzana\",\"cantidad\":\"6\"},\n"+
            "{\"nombre_fruta\":\"Pera\",\"cantidad\":\"4\"}]";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DBHelper dbHelper = new DBHelper(MainActivity.this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        if(db != null){
            Toast.makeText(MainActivity.this, "Base de datos creada", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(MainActivity.this, "Error en crear la base de datos", Toast.LENGTH_LONG).show();
        }

        try{
            JSONArray jArray = new JSONArray(CADENA);
            for(int i = 0; i <jArray.length(); i++){
                JSONObject json_data = jArray.getJSONObject(i);
                String nombre = json_data.getString("nombre_fruta");
                int unidades = json_data.getInt("cantidad");
                Fruta fruta = new Fruta(nombre, unidades);
                dbHelper.insertarFruta(fruta, db);
            }
        } catch (JSONException e) {
            System.out.println(e.getMessage());
        }

    }
}