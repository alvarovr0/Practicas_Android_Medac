package com.example.json;

public class Fruta {
    private String nombre;
    private int unidades;

    public Fruta(String name, int unit){
        this.nombre = name;
        this.unidades = unit;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getUnidades() {
        return unidades;
    }

    public void setUnidades(int unidades) {
        this.unidades = unidades;
    }
}
