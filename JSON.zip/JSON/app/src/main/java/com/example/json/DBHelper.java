package com.example.json;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    private static final int Database_Version = 1;
    private static final String Database_Name = "fruta.db";
    private static final String Table = "t_frutas";
    public DBHelper(@Nullable Context context) {
        super(context, Database_Name, null, Database_Version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE " + Table + "(" + "id integer primary key autoincrement," + "nombre text not null," +
                "cantidad int not null)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("Drop table " + Table);
        onCreate(sqLiteDatabase);
    }

    public void close(SQLiteDatabase db){
        if(db != null){
            db.close();
        }
    }

    public void insertarFruta(Fruta fruta, SQLiteDatabase db){
        ContentValues cv = new ContentValues();
        cv.put("nombre", fruta.getNombre());
        cv.put("cantidad", fruta.getUnidades());
        db.insert(Table, null, cv);
    }
}
