package com.example.framelayout;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import java.io.File;

public class MainActivity extends AppCompatActivity {
    MediaPlayer music;
    private ImageView imagv,imagv2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imagv = (ImageView) findViewById(R.id.maradona);
        imagv2 = (ImageView) findViewById(R.id.mbappe);
        try{
            music = MediaPlayer.create(this, R.raw.drill);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void reproducir(View v){
        imagv.setVisibility(View.VISIBLE);
        imagv2.setVisibility(View.INVISIBLE);
        music.start();
    }

    public void pausar(View v){
        if(music.isPlaying()){
            music.pause();
        }
    }

    public void parar(View v){
        if(music.isPlaying()){
            imagv.setVisibility(View.INVISIBLE);
            imagv2.setVisibility(View.VISIBLE);
            music.stop();
            music = MediaPlayer.create(this, R.raw.drill);
        }
    }
    public void prueba(View v) {
        String path = Environment.getStorageDirectory().toString()+"/raw/";
        Log.d("Files", "Path: " + path);
        File directory = new File(path);
        File[] files = directory.listFiles();
        if(directory.canRead() && files!=null) {
            Log.d("Files", "Size: " + files.length);
            for(File file: files)
                Log.d("FILE",file.getName());
        }
        else
            Log.d("Null?", "it is null");
    }

}