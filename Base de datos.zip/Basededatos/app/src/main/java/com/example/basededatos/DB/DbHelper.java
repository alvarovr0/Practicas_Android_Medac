package com.example.basededatos.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.basededatos.MainActivity;
import com.google.android.material.tabs.TabLayout;

public class DbHelper extends SQLiteOpenHelper {
    private static final int Database_Version = 1;
    private static final String Database_Name = "agenda.db";
    private static final String Table_Contactos = "t_contactos";
    public DbHelper(@Nullable Context context) {
        super(context, Database_Name, null, Database_Version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE " + Table_Contactos + "(" + "id integer primary key autoincrement," + "nombre text not null," +
                "telefono text not null," + "correo_electronico text)");
        ContentValues cv = new ContentValues();
        cv.put("nombre", "Ramon");
        cv.put("telefono", "531753124");
        cv.put("correo_electronico", "Ramon@patata.es");
        sqLiteDatabase.insert(Table_Contactos, null, cv);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("Drop table " + Table_Contactos);
        onCreate(sqLiteDatabase);
    }
}
