package com.example.enlace;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ListView lista;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //if (findViewById(R.id.campo1).isFocusable()){
        //   findViewById(R.id.campo2).requestFocus();
        //}
        //ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, coches);
        //AutoCompleteTextView textView = (AutoCompleteTextView) findViewById(R.id.coches);
        //textView.setAdapter(adapter);
        //CheckBox checkBox1 = (CheckBox) findViewById(R.id.checkbox1);
        //if(checkBox1.isChecked()){
        //   int id = getResources().getIdentifier("@drawable/gokuboca.jpg", null, null);
        //    imageview.s
        //}
        Listado listado = new Listado();
        ArrayList <ListaEntrada> datos = listado.devolverDatos();
        lista = (ListView) findViewById(R.id.Listado);

        lista.setAdapter(new ListaAdaptador(this, R.layout.articulo, datos) {
            @Override
            public void onEntrada(Object entrada, View view) {
                if (entrada != null) {
                    TextView texto_sup_entrada = (TextView) view.findViewById(R.id.textView_superior);
                    if (texto_sup_entrada != null) {
                        texto_sup_entrada.setText(((ListaEntrada) entrada).getTextoEncima());
                    }
                    TextView texto_inf_entrada = (TextView) view.findViewById(R.id.textView_Inferior);
                    if (texto_inf_entrada != null) {
                        texto_inf_entrada.setText(((ListaEntrada) entrada).getTextoDebajo());
                    }
                    ImageView imagenEntrada = (ImageView) view.findViewById(R.id.imageView_image);
                    if (imagenEntrada != null) {
                        imagenEntrada.setImageResource(((ListaEntrada) entrada).getIdImagen());
                    }
                }
            }
        });
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                ListaEntrada elegido = (ListaEntrada) adapterView.getItemAtPosition(i);
                TextView texto_sup_entrada = (TextView) view.findViewById(R.id.textView_superior);
                Context context = getApplicationContext();
                CharSequence text = "Has elegido a " + elegido.getTextoEncima();
                int duration = Toast.LENGTH_LONG;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
        });


    }

   // private static final String[] coches = new String[]{
    //  "Volvo", "Toyota", "Ferrari", "Audi", "BMW", "Renault"
    //};
}