package com.example.enlace;

import java.util.ArrayList;

public class Listado {
    public ArrayList<ListaEntrada> datos;

    Listado(){
        datos = new ArrayList<ListaEntrada>();
        datos.add(new ListaEntrada(R.drawable.gokuboca, "Goku", "Siempre gana"));
        datos.add(new ListaEntrada(R.drawable.vegetariver, "Vegeta", "Siempre pierde (al igual que river)"));
        datos.add(new ListaEntrada(R.drawable.bugordo, "Bu", "Ta gordito"));
        datos.add(new ListaEntrada(R.drawable.krilin, "Krilin", "Puto calvo"));
        datos.add(new ListaEntrada(R.drawable.bills, "Bills", "Gato calvo y desnutrido"));
        datos.add(new ListaEntrada(R.drawable.chaos, "Chaos", "No está calvo, tiene un pelo"));
    }

    public ArrayList<ListaEntrada> devolverDatos(){
        return datos;
    }
}
