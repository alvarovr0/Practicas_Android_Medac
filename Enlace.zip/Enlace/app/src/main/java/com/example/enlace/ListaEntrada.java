package com.example.enlace;

public class ListaEntrada {
    private int idImagen;
    private String textoEncima, textoDebajo;

    public ListaEntrada(int idImagen, String textoEncima, String textoDebajo){
        this.idImagen = idImagen;
        this.textoEncima = textoEncima;
        this.textoDebajo = textoDebajo;
    }

    public String getTextoDebajo() {
        return this.textoDebajo;
    }

    public String getTextoEncima() {
        return this.textoEncima;
    }

    public int getIdImagen() {
        return this.idImagen;
    }
}
