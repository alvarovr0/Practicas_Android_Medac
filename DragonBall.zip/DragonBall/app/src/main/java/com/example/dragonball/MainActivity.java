package com.example.dragonball;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RequestQueue queue;
    ArrayList<Personaje> personajes = new ArrayList<>();
    private TextView edNombre, edEdad, edRaza, edPlaneta, edUniverso;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edNombre = findViewById(R.id.nombre);
        edEdad = findViewById(R.id.edad);
        edRaza = findViewById(R.id.raza);
        edPlaneta = findViewById(R.id.planeta);
        edUniverso = findViewById(R.id.universo);
        obtenerDatos(personajes);
    }
    private void obtenerDatos(ArrayList<Personaje> personajes){
       queue = Volley.newRequestQueue(this);
       String url = "http://10.192.240.158/tema8/tema8/php/obtenerTodasPersonajes.php";

       JsonArrayRequest jsonObjectRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
           @Override
           public void onResponse(JSONArray response) {
               try {
                   JSONArray datospersonas = response.getJSONObject(0).getJSONArray("mensaje");
                   Log.d("Falla en el Json", "Hola");
                   for (int i = 0; i < datospersonas.length(); i++) {
                       JSONObject pj = datospersonas.getJSONObject(i);
                       String nombrePersonaje = pj.getString("Nombre");
                       String edadPersonaje = pj.getString("Edad");
                       String razaPersonaje = pj.getString("Raza");
                       String planetaPersonaje = pj.getString("Planeta");
                       String universoPersonaje = pj.getString("Universo");

                       Personaje pnj = new Personaje(nombrePersonaje, edadPersonaje, razaPersonaje, planetaPersonaje, universoPersonaje);

                       personajes.add(pnj);
                       Log.d("hola", personajes.get(0).nombre);
                   }
                   edNombre.setText(personajes.get(0).nombre);
                   edEdad.setText(personajes.get(0).edad);
                   edRaza.setText(personajes.get(0).raza);
                   edPlaneta.setText(personajes.get(0).planeta);
                   edUniverso.setText(personajes.get(0).universo);
               } catch (JSONException e) {
                   e.printStackTrace();
               }
           }
       }, new Response.ErrorListener() {
           @Override
           public void onErrorResponse(VolleyError error) {

           }
       });
       queue.add(jsonObjectRequest);
    }
}