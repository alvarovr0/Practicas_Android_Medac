package com.example.dragonball;

public class Personaje {
    String nombre, raza, planeta, edad, universo;

    public Personaje(String nombre, String edad, String raza, String planeta, String universo){
        this.nombre = nombre;
        this.edad = edad;
        this.raza = raza;
        this.planeta = planeta;
        this.universo = universo;
    }
}
