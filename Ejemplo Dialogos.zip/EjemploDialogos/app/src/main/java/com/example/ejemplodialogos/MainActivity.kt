package com.example.ejemplodialogos

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val boton = findViewById<Button>(R.id.button)

        boton.setOnClickListener{
            val dialogo = AlertDialog.Builder(this)

            dialogo.setMessage("¿Quieres salir de la aplicación?")
                .setCancelable(false)
                .setPositiveButton("Sí, quiero salir"){
                    dialog, id -> finish()
                }
                .setNegativeButton("No, no quiero"){
                    dialog, id -> dialog.cancel()
                }

            val alerta = dialogo.create()
            alerta.setTitle("Mi primera alerta")
            alerta.show()
        }
    }
}