package com.example.linearlayout2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    private EditText et1;
    private EditText et2;
    private TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1 = findViewById(R.id.et1);
        et2 = findViewById(R.id.et2);
        tv1 = findViewById(R.id.tv1);
    }
    public void sumar(View view) {
        int num1 = Integer.parseInt(et1.getText().toString());
        int num2 = Integer.parseInt(et2.getText().toString());
        int suma = num1 + num2;
        String result = String.valueOf(suma);
        tv1.setText(String.valueOf(num1 + num2));
    }
    public void restar(View view) {
        int num1 = Integer.parseInt(et1.getText().toString());
        int num2 = Integer.parseInt(et2.getText().toString());
        int resta = num1 - num2;
        String result = String.valueOf(resta);
        tv1.setText(result);
    }
    public void multiplicar(View view) {
        int num1 = Integer.parseInt(et1.getText().toString());
        int num2 = Integer.parseInt(et2.getText().toString());
        int multi = num1 * num2;
        String result = String.valueOf(multi);
        tv1.setText(result);
    }
    public void dividir(View view) {
        int num1 = Integer.parseInt(et1.getText().toString());
        int num2 = Integer.parseInt(et2.getText().toString());
        int div = num1 / num2;
        String result = String.valueOf(div);
        tv1.setText(result);
    }
}